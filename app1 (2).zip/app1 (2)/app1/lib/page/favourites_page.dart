import 'package:flutter/material.dart';

class FavouritesPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text('Favourites'),
      centerTitle: true,
      backgroundColor: Colors.red,
    ),
  );
}